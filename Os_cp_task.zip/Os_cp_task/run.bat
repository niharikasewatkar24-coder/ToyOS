@echo off
wsl bash -c "cd '/mnt/c/Users/Prathamesh Kumbhare/Downloads/files' && ./build_and_run.sh"
pause 